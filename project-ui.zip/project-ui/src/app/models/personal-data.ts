export interface personalData {
    fullName: String;
    age: number;
    poids: number;
}
