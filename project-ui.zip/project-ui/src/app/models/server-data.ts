export interface ServerData {
    Calorie: number;
    Deportation: number;
    Distance: number;
    Vitesse: number;
}
