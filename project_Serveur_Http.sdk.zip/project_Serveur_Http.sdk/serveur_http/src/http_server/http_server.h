/*
 * http_server.h
 *
 */

#ifndef HTTP_SERVER_H
#define HTTP_SERVER_H

/* initialize and start the web server */
int start_web_application();

#endif


